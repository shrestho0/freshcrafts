# freshbeans_poc
POC of the project for Therap Java Fest
