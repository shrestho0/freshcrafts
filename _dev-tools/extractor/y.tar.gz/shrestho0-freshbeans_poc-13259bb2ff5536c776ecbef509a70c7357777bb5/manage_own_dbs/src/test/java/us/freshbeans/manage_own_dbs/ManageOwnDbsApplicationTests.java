package us.freshbeans.manage_own_dbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageOwnDbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
