package me.shrestho.nginx_wrapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NginxWrapperApplicationTests {

	@Test
	void contextLoads() {
	}

}
