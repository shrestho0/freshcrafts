```

This project is here for testing purposes
and all the code has been taken from this link: https://www.prisma.io/blog/sveltekit-prisma-kvCOEoeQlC

```



<span style="color:crimson;"> Ignore from this line</span>

Check this out: https://www.prisma.io/docs/orm/prisma-migrate/understanding-prisma-migrate/shadow-database#cloud-hosted-shadow-databases-must-be-created-manually